package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Breakabletoy2Application {

	public static void main(String[] args) {
		SpringApplication.run(Breakabletoy2Application.class, args);
	}

}
